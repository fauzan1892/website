<? include 'header.php' ?>
	<body>
		<section id="contact-info">
			<div class="row">
				<div class="container">
					<div class="center">                
						<h2>Tempat pemesanan</h2>
						<p class="lead">Kami melakukan transaksi dengan cara menghubungi via sosial media, email dan telepon kami juga dapat melakukan COD di bekasi dan sekitar nya</p>
							<div class="social-icons">
								<h4 style="color:#333;	">Hubungi kami lewat sosial media</h4>
									<ul class="nav navbar-nav2">
										   <li><h3><a href="https://www.facebook.com/Any-Shop-1710361995915704/?refid=52&_ft_=top_level_post_id.1710437049241532%3Atl_objid.1710437049241532%3Athid.1710361995915704&__tn__=C" target="_blank"><i class="fa fa-facebook"></i></a></h2></li><!--terserah facebook -->
										   <li><h3><a href="" target="_blank"><i class="fa fa-twitter"></i></a></h2></li><!--terserah twitter -->
										   <li><h3><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></h2></li><!--linkedin-->
											<li><h3><a href="" target="_blank"><i class="fa fa-instagram"></i></a></h2></li><!--terserah intagram any -->
										   <li><h3><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></h2></li><!--googlepelus lu-->
									</ul>
							</div>
					</div>
				</div>
			</div>
			<br>
			<div class="buat-map">
				<div class="container">
					<div class="row">
						<div class="col-sm-5 text-center">
							<div class="map">
								<img src="foto/Screenshot from 2016-04-30 19:09:10.png" class="img-circle" style="width:100%; height:auto;">
							</div>
						</div>
						<div class="col-sm-7 map-content">
							<ul class="row">
								<li class="col-sm-6">
									<address>
										<h5>Head Office</h5>
										<p>Villa gading harapan <br>
										blok,??, kec. babelan kab bekasi </p>
										<p>Phone: 0882-1244-0642 <br>
										Email Address:info@domain.com</p>
									</address>
									
									<address>
										<h5>Zonal Office</h5>
										<p>uj harapan kav daruttaqwa <br>
										rt 05/014 no 25,kec babelan kab bekasi</p>                                
										<p>Phone: 0896-1817-3609 <br>
										Email Address:fauzanfalah@gmail.com</p>
									</address>
								</li>
								<li class="col-sm-6">
									<address>
										<h5>Zone#2 Office</h5>
										<p>kranji <br>
										alamat, tempat</p>
										<p>Phone:- <br>
										Email: kathonmeazza@gmail.com</p>
									</address>

									<address>
										<h5>Zone#3 Office</h5>
										<p>belum tau<br>
										alamat, tempat</p>
										<p>Phone:-<br>
										Email Address:info@domain.com</p>
									</address>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>  <!--/gmap_area -->

		<section id="contact-page">
			<div class="container">
				<div class="center">        
					<h2>Kirim pesan </h2>
					<p class="lead">Anda dapat melakukan transaksi via email .. biasa nya di jawab pada jam 18.00 - 22.00 wib</p>
				</div> 
					<div class="row contact-wrap">  
						<div class="status alert alert-success" style="display: none"></div>
						<form id="main-contact-form" class="contact-form" name="contact-form" method="post" action="sendemail.php">
							<div class="col-sm-5 col-sm-offset-1">
								<div class="form-group">
									<label>Name *</label>
									<input type="text" name="name" class="form-control" required="required">
								</div>
								<div class="form-group">
									<label>Email *</label>
									<input type="email" name="email" class="form-control" required="required">
								</div>
								<div class="form-group">
									<label>Phone</label>
									<input type="number" class="form-control">
								</div>
								<div class="form-group">
									<label>Url Sosial Media</label>
									<input type="text" class="form-control">
								</div>                        
							</div>
							<div class="col-sm-5">
								<div class="form-group">
									<label>Subject *</label>
									<input type="text" name="subject" class="form-control" required="required">
								</div>
								<div class="form-group">
									<label>Message *</label>
									<textarea name="message" id="message" required="required" class="form-control" rows="8"></textarea>
								</div>                        
								<div class="form-group">
									<button type="submit" name="submit" class="btn btn-danger btn-lg" required="required">Submit Message</button>
								</div>
							</div>
						</form>  
				</div><!--/.row-->
			</div><!--/.container-->
		</section><!--/#udhcontak-->
		<br>
		<div style="clear:both;"></div>
	
	</body>
<? include 'footer.php' ?>
