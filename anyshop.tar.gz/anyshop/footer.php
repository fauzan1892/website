<? //session_start ();?>
	<section id="footer1">
				<div class="row">
					<br>
					<div class="container">
						<div class="col-lg-3 col-sm-3">
							<h4>Information</h4>
									<h4 style="color:white;">
										<p><a href="" style="color:white;">Jasa Download</a></p>
									
										<p><a href="" style="color:white;">Jasa editing foto/gambar </a></p>
									
										<p><a href="" style="color:white;">Pembayaran online</a></p>
									
										<p><a href="" style="color:white;"> Voucher Games/pulsa all operator</a></p>
									</h4>
									
						</div>
							<div class="col-lg-3 col-sm-3">
								<h4>Follow us</h4>
								<br>
								<div class="social-icon pull-center">
									<ul class="nav navbar-nav1">
										<div class="container">
											<li><a href="" target="_blank"><i class="fa fa-facebook"></i></a></li><!--terserah facebook -->
											<li><a href="" target="_blank"><i class="fa fa-twitter"></i></a></li><!--terserah twitter -->
											<li><a href="" target="_blank"><i class="fa fa-instagram"></i></a></li><!--terserah intagram any -->
											<li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li><!--linkedin-->
											<li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li><!--googlepelus lu-->
										</div>
									</ul>
								</div>
									
							</div>
						<div class="col-lg-3 col-sm-3">
								<h4>Email Updates</h4>
								<h4><p>Be the first to hear about our offers and announcements. </p>
								<form class="form-inline" role="form" action="">
									<input type="text" placeholder="Enter Your email address" class="form-control" class="fa fa-envelope">
									<br><br>
								</h4>
								</form>
							</div>
							 <div class="col-lg-3 col-sm-3">
								 <h4>Contact us</h4>
								 <h4>Question ? We've got anwers, Try us.<br><br>
								 <button class="btn btn-warning btn-lg" type="button"> Email US<br></i></button>
								 
							</div>
						</div>
						<div class="container">
							<p class="pull-right"><a href=""><i style="color:white;font-size:20px;">Kembali ke atas</i></a></p>
						</div>
					</div>
				</div>
				<hr></hr>
		<div id="footer">
			<div class="container">
				<div class="row">
					<p class="pull-left"><b>Copyright &copy; 2016 Any Online Shop All rights reserved.</b></p>
					<p class="pull-right"><b>Powered by <span><a href="https://www.facebook.com/fauzan.falah2"style="color:#AAF6F6;">Code lima</b></a></span></p>
				</div>
			</div>
		</div>
	</section>
	
	</body>
	<div class="cart">
		<a href="#kepala"><i class="fa fa-angle-up"></i> <span>Keatas</span></a>
	</div>
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/main.js"></script>
		<script src="js/wow.min.js"></script>
		<script src="googleapis.css"></script>
</html>
