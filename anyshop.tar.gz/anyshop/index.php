<? //session_start ();?>
<? include 'header.php' ?>
		<br>
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<br>
					<div id="slideshow-mudah" class="carousel slide" data-ride="carousel">
							<!-- Indicators -->
						<ol class="carousel-indicators">
							<li data-target="#slideshow-mudah" data-slide-to="0" class="active"></li>
							<li data-target="#slideshow-mudah" data-slide-to="1"></li>
							<li data-target="#slideshow-mudah" data-slide-to="2"></li>
							<li data-target="#slideshow-mudah" data-slide-to="3"></li>
						</ol>
 
							<!-- Wrapper for slides, Ini adalah Tempat Gambar-->
					<div class="carousel-inner">
						<div class="item active">
							<img src="foto/Kursus-Toko-Online.jpg" alt="slideshow-mudah"> <!-- Gambar -->
							<div class="carousel-caption wow fadeInDown"> <!--Penjelasan -->
								
								<h1 style="color:#ECF0F1;"><b>Any Online Shop<span style="position: relative; top: -20px; font-size: 15px">&reg </span></b></h1>
								<h2 style="color:#ECF0F1;"> <b>Menyediakan Jasa Editing foto/gambar, Jasa Download, Pembayaran Online, Voucher games dsb</b></h2>
							</div>
					</div>
				<div class="item">
					<img class="" src="foto/main_picture.png" alt="slideshow-mudah"> <!--Gambar -->
						<div class="carousel-caption wow fadeInDown">  <!--Penjelasan -->
						<h1 style="color:#ECF0F1;"><b>Pembayaran online </h1>
						<h2 style="color:#ECF0F1;">Disini menyediakan pembayaran token listrik/biasa, PDAM, telepon, pulsa elektrik dan sebagainya </b></p></h2>
				</div>
			</div>
				<div class="item">
					<img src="foto/wow.jpg" alt="slideshow-mudah"> <!--Gambar -->
						<div class="carousel-caption wow fadeInDown"> <!--Penjelasan -->
						<h1 style="color:#ECF0F1"><b>Voucher Games <span style="position: relative; top: -20px; font-size: 15px">&reg </span></b></h1>
						<h2 style="color:#ECF0F1;"><center><b>Gemscool, Megaxus, Net Marble, Zynga, dan masih banyak lagi, bagi temen-temen Gamers yang ingin memesan, bisa langsung hubungi kami. </b> </center></h2>
				</div>
			</div>
				<div class="item">
					<center><img src="foto/gw.png" alt="slideshow-mudah"> <!--Gambar --></center>
						<div class="carousel-caption wow fadeInDown"> <!--Penjelasan -->
						<h1 style="color:#ECF0F1"><b></b></h1>
						<h2 style="color:#ECF0F1;"><center><b> </b> </center></h2>
				</div>
			</div>
		</div>
 
				<!-- Controls, Ini adalah Panah Kanan dan Kiri-->
		<a class="left carousel-control" href="#slideshow-mudah" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
		</a>
		<a class="right carousel-control" href="#slideshow-mudah" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
		</a>
		</div>
		<br>
		<br>
		<br>
		<section id="home">
			<div id="row">
				<div class="container">
						<div id="top"></div>
					<!-- Progress bar area -->
					<div class="progress bar"></div>
					<a href="#top" class="ui circular icon button" id="toTop" data-slide="slide">
						<i class="angle up icon"></i>
					</a>
	
					<div class="col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
						<div class="panel-primary">
							<h3 style><b><p>Pembayaran online <img src="Icon/affiliatemarketing2 copy.png" class="img-circle" id="img10"></b></h3>
							<div class="panel panel-default">
								<div class="panel-body">		
								<h4><center><b>memudahkan anda tanpa harus mengantri dengan pembayaran online melalui internet </b> <br><br> 
								<a href="pesan.php"><button class="btn btn-success" type="button">Pesan Sekarang</button></a></center></h4>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
						<div class="panel-primary">
							<h3 style><b><p>Jasa Download <img src="Icon/download-512.png" class="img-circle" id="img10"></b></h3>
							<div class="panel panel-default">
								<div class="panel-body">		
								<h4><center><b> Jasa download Game, Film sesuai dengan kebutuhan anda Sedang promo Diskon 5% /Gb </b> <br><br>
								<a href="pesan.php"><button class="btn btn-success" type="button">Pesan Sekarang</button></a></center></h4>
								</div>
							</div>
						</div>
					</div>
					<div id="row">
					<div class="col-sm-6">
						<div class="panel-primary">
							<h3 style><b><p>Vocher games, pulsa hp/internet <img src="Icon/5-website-tempat-belanja-online.png" class="img-circle" id="img10"></b></h3>
							<div class="panel panel-default">
								<div class="panel-body">		
								<h4><center><b> Hai para Gamers, kami juga jual Voucher Games mulai dari Gemscool, Megaxus, Net Marble, Zynga </b> <br><br>
								<a href="pesan.php"> <button class="btn btn-success" type="button">Pesan Sekarang</button></a></center></h4>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="panel-primary">
							<h3 style><b><p>Jasa editing foto/gambar <img src="Icon/katon.png" class="img-circle" id="img10"></b></h3>
							<div class="panel panel-default">
								<div class="panel-body">		
								<h4><center><b> Sedang promo Diskon 5%, jasa editing foto dimulai dari vektor vexel dsb ayo pesan sekarang !!  </b> <br><br>
								<a href="pesan.php"> <button class="btn btn-success" type="button">Pesan Sekarang</button></a></center></h4>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="second"></div>
		</section>
		<br><br><br>
		<section id="home1">
			<div style="" id="third">
				<br>
				<center>
				<h2 style="color:white;"><b>Any Online Shop</b></h2>
				<h3 style="color:white;"><b>Kami Menyediakan Jasa Editing foto/ gambar, Jasa Download, Pembayaran Online, Voucher games dsb</b></h3>
				</center>
					<div class="row">
						<div class="container">
							<div class="col-sm-4 col-sm-6 wow fadeInDown">
								<div class="transparent">
									<center><img src="foto/index.png" class="pull-right">
										<h3 class="kepalanya">
										<i class="icon-custom icon-lg icon-bg-yellow icon-book-open"></i><br>
										<span>Jasa Download / Jasa editing foto/ gambar</span>	<br><br>								   
										<span>Tersedia</span>									   
										</h3><img src="#" alt=""><!--gambar promosiannya -->
										<br>
									   <p><i class="fa fa-check color-green"></i> FILE, FILM / VIDEO, YOUTUBE DLL </p>
									   <p><i class="fa fa-check color-green"></i> EDIT FOTO, VECTOR, VEXEL dan sebagainya</p>
									   <p><i class="fa fa-check color-green"></i> ALL SOFTWARE</p>
									   <p><i class="fa fa-check color-green"></i> GAMES </p>
									   <p><i class="fa fa-check color-green"></i> Sesuai Permintaan</p>
									   <p><i class="fa fa-check color-green"></i> TERIMA UPLOAD <br>Torrent, 4Shared dan sebagainya</p>
									  Pekerjaan selama 3-7 hari <br>* tergantung antrian dan kondisi jaringan.
									   <br><br>
									   <a href="pesan.php"><button class="btn btn-success">PESAN SEKARANG</button></a>
									   <br><br>
									   </center>
							</div>
						</div>
						<div class="col-sm-4 col-sm-6 wow fadeInDown">
								<div class="transparent">
									<center><img src="foto/index.png" class="pull-right">
										<h3 class="kepalanya">
										<i class="icon-custom icon-lg icon-bg-yellow icon-book-open"></i><br>
										<span>Pembayaran online</span><h3>	<br>							   
										<span>Menerima pembayaran:</span></h3>						   
										</h3>
										
										</h2><img src="#" alt=""><!--gambar promosiannya -->
										<br>
									   <p><i class="fa fa-check color-green"></i> Token Listrik / biasa</p>
									   <p><i class="fa fa-check color-green"></i> Wifi, Indi Home,Speedy, Firstmedia, Telkom Indonesia dsb </p>
									   <p><i class="fa fa-check color-green"></i> ADIRA, Wow Finance, HD finance,</p>
									   <p><i class="fa fa-check color-green"></i> Telepon, PAM</p>
									   <p><i class="fa fa-check color-green"></i> Kredit motor FIF, telkom Vision</p>
									   <p><i class="fa fa-check color-green"></i> All TV Berbayar, Indovision, Orange TV, dsb</p>
									   <p><i class="fa fa-check color-green"></i> Sesuai Permintaan</p>
									   <p><i class="fa fa-check color-green"></i> All pulsa Seluruh Operator </p>
									   <br><br>
									   <a href="pesan.php"><button class="btn btn-success">PESAN SEKARANG</button></a>
									   <br><br><br>
									   </center>
							</div>
						</div>
						<div class="col-sm-4 col-sm-6 wow fadeInDown">
								<div class="transparent">
									<center><img src="foto/index.png" class="pull-right">
										<h3 class="kepalanya">
										<i class="icon-custom icon-lg icon-bg-yellow icon-book-open"></i><br>
											<span>Voucher Games</span><h3><br>					   
										<span>Tersedia Voucher <br> All Games:</span></h3>						   
										</h3>
										
										</h2><img src="#" alt=""><!--gambar promosiannya -->
										<br>
									   <p><i class="fa fa-check color-green"></i> Gemscool</p>
									   <p><i class="fa fa-check color-green"></i> Garena </p>
									   <p><i class="fa fa-check color-green"></i> Zynga</p>
									   <p><i class="fa fa-check color-green"></i> Lyoto</p>
									   <p><i class="fa fa-check color-green"></i> Megaxus</p>
									   <p><i class="fa fa-check color-green"></i> STEAM</p>
									   <p><i class="fa fa-check color-green"></i> Dan lain-lain</p>
									   <p><i class="fa fa-check color-green"></i> Sesuai Permintaan</p>
									   <a href="pesan.php"><button class="btn btn-success"> PESAN SEKARANG</button></a>
									   <br><br>
									   </center>
								</div>	   
							</div>
						</div>
						<br><br>
					</div>
				</div>
			</div>
	</section>
	<section id="home2">
		<div class="container">
			<div class="row">
				<h3 class="text-center">Harga voucher all games dan pulsa</h3>
				<hr>
				<div class="col-sm-3">
				  <div class="panel panel-warning text-center">
					<div class="panel-heading">
					  <h3>Gemscool</h3>
					</div>
					<div class="panel-body">
					   <h3 class="panel-title price">Rp.11<span class="price-cents">.000</span><span class="price-month"></span></h3>
					</div>
					<ul class="list-group">
						<b>Gemscool - kreon per voucher</b>
					<ul class="list-group">
					  <li class="list-group-item">cash /coin 1000 / Rp 11.000</li>
					  <li class="list-group-item">cash /coin 2000 / Rp 21.000</li>
					  <li class="list-group-item">cash /coin 3000 / Rp 31.000</li>
					  <li class="list-group-item">cash /coin 5000 / Rp 51.000</li>
					  <li class="list-group-item">cash /coin 10000 / Rp 101.000</li>
					  <li class="list-group-item">cash /coin 20000 / Rp 195.000</li>
					  <li class="list-group-item"><a class="btn btn-warning" href="pesan.php">Pesan Sekarang !</a></li>
					</ul>
				  </div>          
				</div>
				<div class="col-sm-3">
				  <div class="panel panel-danger text-center">
					<div class="panel-heading">
					  <h3>Garena</h3>
					</div>
					<div class="panel-body">
					   <h3 class="panel-title price">Rp.12<span class="price-cents">.000</span><span class="price-month"></span></h3>
					</div>
					<ul class="list-group">
						<b>Garena indonesia per voucher</b>
					<ul class="list-group">
					  <li class="list-group-item">cash /coin 1000 / Rp 12.000</li>
					  <li class="list-group-item">cash /coin 2000 / Rp 22.000</li>
					  <li class="list-group-item">cash /coin 3000 / Rp 32.000</li>
					  <li class="list-group-item">cash /coin 5000 / Rp 52.000</li>
					  <li class="list-group-item">cash /coin 10000 / Rp 102.000</li>
					  <li class="list-group-item">cash /coin 20000 / Rp 196.000</li>
					  <li class="list-group-item"><a class="btn btn-danger" href="pesan.php">Pesan Sekarang !</a></li>
					</ul>
				  </div>          
				</div>
				<div class="col-sm-3">
				  <div class="panel panel-info text-center">
					<div class="panel-heading">
					  <h3>Megaxus</h3>
					</div>
					<div class="panel-body">
					   <h3 class="panel-title price">Rp.11<span class="price-cents">.000</span><span class="price-month"></span></h3>
					</div>
					<ul class="list-group">
						<b>Megaxus per voucher</b>
					<ul class="list-group">
					  <li class="list-group-item">cash /coin 1000 / Rp 11.000</li>
					  <li class="list-group-item">cash /coin 2000 / Rp 21.000</li>
					  <li class="list-group-item">cash /coin 3000 / Rp 31.000</li>
					  <li class="list-group-item">cash /coin 5000 / Rp 51.000</li>
					  <li class="list-group-item">cash /coin 10000 / Rp 101.000</li>
					  <li class="list-group-item">cash /coin 20000 / Rp 195.000</li>
					  <li class="list-group-item"><a class="btn btn-info" href="pesan.php">Pesan Sekarang !</a></li>
					</ul>
				  </div>          
				</div>
				<div class="col-sm-3">
				  <div class="panel panel-success text-center">
					<div class="panel-heading">
					  <h3>LYTO</h3>
					</div>
					<div class="panel-body">
					   <h3 class="panel-title price">Rp.11<span class="price-cents">.000</span><span class="price-month"></span></h3>
					</div>
					<ul class="list-group">
						<b>LYTO per voucher</b>
					<ul class="list-group">
					  <li class="list-group-item">cash /coin 1000 / Rp 11.000</li>
					  <li class="list-group-item">cash /coin 2000 / Rp 21.000</li>
					  <li class="list-group-item">cash /coin 3000 / Rp 31.000</li>
					  <li class="list-group-item">cash /coin 5000 / Rp 51.000</li>
					  <li class="list-group-item">cash /coin 10000 / Rp 101.000</li>
					  <li class="list-group-item">cash /coin 20000 / Rp 195.000</li>
					  <li class="list-group-item"><a class="btn btn-success" href="pesan.php">Pesan Sekarang !</a></li>
					</ul>
				  </div>          
				</div>
				<br><br>				
				<center><h3 style="color:black;"><b>* Untuk Voucher Games lain masih di hargai dengan tarif yang sama tergantung promo dan diskon yang telah di tentukan *</b></h3></center>
				<center><a href=""><button class="btn btn-info ">Lihat Lebih Voucher Games lainnya !</button></a></center>
				<center><h4 style="color:black;">Terima kasih untuk pesanannya #AYO BERMAIN
				<center><h4 style="color:black;">dan Untuk pulsa tarif seperti biasa di counter-counter terdekat </h4><h5 style="color:black;">
				 <br> dapat via COD sekitar Bekasi Utara.</h5></center>
			
			</div>
		</div> 
	</section>
	<section id="homee">
		 <center><h2>PEMBAYARAN ONLINE</h2>
		 <img src="foto/banner-ppob-bukopin-pulsa.jpg" class="img7"><!--buat dong lagi cukk  --></center>
		 <br><br>
		<center>Alamat :</center> 
		<br><br>
	</section>
		<section id="home3" class="pricing-table">
			<div class="container">
			  <div class="pricing-table">
				<div class="row">
					<center><h1>Jasa Download FILE/GAME/SOFTWARE/FILM(VIDEO), DLL dan Jasa  Editing Foto/Gambar</h1>
					<img class="img1"src="foto/download.gif" class="img-circle" id="tengah"></center>

				  <!-- First package -->
				  <div class="col-md-4">
					<div class="package">
					  <div class="header-package-1 text-center">
						<h3>Jasa Download 0-19.9GB</h3>										
					   <!-- <img class="img1"src="#" class="img-circle" id="img8"> masih belum di gunakan -->
						<div class="price"><h4>Rp 4000,-/GB/GB+</h4></div>
					  </div>

					  <!-- details -->
					  <div class="package-features text-center">
						<ul>
						  <li>File</li>
						  <li>FILM/VIDEO, YOUTUBE DLL</li>
						  <li>ALL SOFTWARE</li>
						  <li>GAMES</li>
						  <li>Sesuai Permintan</li>
						  <li>TERIMA UPLOAD via Torrent, 4 Shared dan sebagainya Garansi 1 minggu</li>
						  <li> Pekerjaan selama 3-7 hari<br>
						* tergantung antrian dan kondisi jaringan. </li>
						</ul>
						<div class="wrp-button text-center"><a href="pesan.php" class="btn standard-button">GET IT</a></div>
						<br>
					  </div>
					</div>
				  </div>

				  <!-- Second package-->
				  <div class="col-md-4">
					  
					<div class="package"><img src="foto/index.png" class="pull-right">
					  <div class="header-package-2 text-center"><br>
						<h3>Jasa Download 20GB-39.9GB 40-60GB  >60GB</h3>										
					   <!-- <img class="img1"src="#" class="img-circle" id="img8"> masih belum di gunakan -->
						<div class="price"><h4>total Rp 6000,-/GB/GB+</h4></div>
					  </div>

					  <!-- details -->
					  <div class="package-features text-center">
						<ul>
						  <li>File</li>
						  <li>FILM/VIDEO, YOUTUBE DLL</li>
						  <li>ALL SOFTWARE</li>
						  <li>GAMES</li>
						  <li>Sesuai Permintan</li>
						  <li>TERIMA UPLOAD via Torrent, 4 Shared dan sebagainya, Gaaransi 2 Minggu</li>
						  <li> Pekerjaan selama 3-7 hari<br>
						* tergantung antrian dan kondisi jaringan. </li>
						</ul>
						<div class="wrp-button text-center"><a href="pesan.php" class="btn standard-button">GET IT</a></div>
						<br>
					  </div>
					</div>
				  </div>

				  <!-- Third package -->
				  <div class="col-md-4">
					<div class="package">
					  <div class="header-package-3 text-center">
						<h3>Jasa editing foto/gambar</h3>
						<div class="price">
						<h4>*harga tergantung pengerjaan yang di minta oleh pemesan</h4>
						</div> 
					  </div>

					  <!-- details -->
					  <div class="package-features text-center">
						<ul>
						<li>tersedia vector wajah </li>
						<li>design logo-logo</li>
						<li>membuat vexel</li>
						<li>vector full body</li>
						<li>vector Close up</li>
						<li>design template</li>
						<li>Sesuai permintaan<br> pemesan
						</li>
						</ul>
						<div class="wrp-button text-center"><a href="pesan.php" class="btn standard-button">GET IT</a></div>
						<br>
					  </div>
					</div>
				  </div>
				 </div> 
			  </div>
			  
				  <center><h1 style="color:black;"><b>Jasa Download +DVD : Rp.6000/pcs</b></h1></center>
								<center><h3 style="color:black;">Contact : What'sApp : 0882-1344-0642 PIN BBM : 7D205561</h3>
								<h4 style="color:black;">
								 Garansi 7 hari dengan syarat file yg di copy ke agan corrupt/rusak/hilang.
								 <br> Tidak menerima compress file *ingin diperkecil. dapat via COD sekitar Bekasi Utara.</h4></center>
								<br><br>
		 
			</div> 
		</div>
		</div>
		</section>
<!--
		belum di tambahhhhh langsung bawahan belum terintegrasi database, masih statis template
-->
		<section id="bottom">
            <center> <h2>Gallery Product</h2> </center>
            <center> <h3>Kami Menyediakan Jasa Editing foto/ gambar, Jasa Download, Pembayaran Online, Voucher games dsb</h3> </center>
		<div id="row">
			<div class="container">
				<div id="event-carousel" class="carousel slide" data-interval="false">
					<div id="slideshow-mudah" class="carousel slide" data-ride="carousel">
							<!-- Indicators -->
							<h1><a class="even-control-left" href="#event-carousel" data-slide="prev"><i class="fa fa-angle-left"></i></a>
							<a class="even-control-right" href="#event-carousel" data-slide="next"><i class="fa fa-angle-right"></i></a></h1>
								<div class="carousel-inner">
									<div class="item active">
										<div class="col-lg-3 col-sm-3">
											<img src="foto/no_image_available.jpg" class="img-responsive">
											<center><a href="pesan.php" class="btn btn-success btn-lg"><i class="fa fa-shopping-cart"></i> Beli</a>
										</div>
										<div class="col-lg-3 col-sm-3">
											<img src="foto/no_image_available.jpg" class="img-responsive">
											<center><a href="pesan.php" class="btn btn-success btn-lg"><i class="fa fa-shopping-cart"></i> Beli</a>
										</div>
										<div class="col-lg-3 col-sm-3">
											<img src="foto/no_image_available.jpg" class="img-responsive">
											<center><a href="pesan.php" class="btn btn-success btn-lg"><i class="fa fa-shopping-cart"></i> Beli</a>
										</div>
										<div class="col-lg-3 col-sm-3">
											<img src="foto/no_image_available.jpg" class="img-responsive">
											<center><a href="pesan.php" class="btn btn-success btn-lg"><i class="fa fa-shopping-cart"></i> Beli</a>
										</div>
									</div>
									<div class="item">
										<div class="col-lg-3 col-sm-3">
											<img src="foto/no_image_available.jpg"class="img-responsive">
											<center><a href="pesan.php" class="btn btn-success btn-lg"><i class="fa fa-shopping-cart"></i>Beli</a>
										</div>
										<div class="col-lg-3 col-sm-3">
											<img src="foto/no_image_available.jpg"class="img-responsive">
											<center><a href="pesan.php" class="btn btn-success btn-lg"><i class="fa fa-shopping-cart"></i> Beli</a>
										</div>
										<div class="col-lg-3 col-sm-3">
											<img src="foto/no_image_available.jpg"class="img-responsive">
											<center><a href="pesan.php" class="btn btn-success btn-lg"><i class="fa fa-shopping-cart"></i> Beli</a>
										</div>
										<div class="col-lg-3 col-sm-3">
											<img src="foto/no_image_available.jpg"class="img-responsive">
											<center><a href="pesan.php" class="btn btn-success btn-lg"><i class="fa fa-shopping-cart"></i> Beli</a>
										</div>
									</div>
						</div>
						<br><br>
						<center><a href=""><button class="btn btn-info btn-lg"><i>Lihat lebih banyak Lagi</i></button></a></center>
						<br>
					</div>
				</div>
			</div>
		</div>
		</section>
<?  include 'footer.php' ?>
