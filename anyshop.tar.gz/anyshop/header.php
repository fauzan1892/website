<? session_start ();?>
<html lang="id">

<!--
 peringatan .. belum terintegrasi database .. masih tahap halaman depan web statis
 design web by :fauzan1892 
-->
	<head>
		<title>Any Shop</title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="keyword"content="any online shop, any shop, Menyediakan Jasa Editing foto/gambar, Jasa Download, Pembayaran Online, Voucher games dsb">
			 <link href="css/bootstrap.min.css" rel="stylesheet">
			 <link href="css/font-awesome.min.css" rel="stylesheet">
			 <link href="css/animate.min.css" rel="stylesheet">
			 <link href="css/jquery.js" rel="stylesheet">
			 <link href="gaya.css" rel="stylesheet">
			 
			 <link href="css/googleapis.css" rel="stylesheet">
			 <link href="icon/12924423_1710362155915688_6317663250708869046_n.jpg" rel="shortcut icon"> <!--atas ikon-->
			 <link href="css/paralax" rel="stylesheet">
			 <script type="text/javascript">
				 $(document).ready(function(){
					$('#third').parallax("75%",0.6);
				 })
			 </script>
	</head>
	<body>
		<section id="kepala"><!--header-->
			<div class="kepala1"><!--header_top-->
				<div class="container">
					<div class="row">
						<div class="col-sm-6">
							<div class="kontak">
								<ul class="kolor">
									<h5>
									<li><a href="#"><i class="fa fa-phone square"></i> 0882-1244-0642</a> | <a href="#"><i class="fa fa-envelope square"></i> info@any_olshop.com</a></li>
									</h5>
								</ul>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="social-icons pull-right">
								<ul class="nav navbar-nav">
									   <li><a href="https://www.facebook.com/Any-Shop-1710361995915704/?refid=52&_ft_=top_level_post_id.1710437049241532%3Atl_objid.1710437049241532%3Athid.1710361995915704&__tn__=C" target="_blank"><i class="fa fa-facebook"></i></a></li><!--terserah facebook -->
									   <li><a href="" target="_blank"><i class="fa fa-twitter"></i></a></li><!--terserah twitter -->
									   <li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li><!--linkedin-->
										<li><a href="" target="_blank"><i class="fa fa-instagram"></i></a></li><!--terserah intagram any -->
									   <li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li><!--googlepelus lu-->
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section><!--/header_top-->
		<section id="header">
			 <nav class="navbar navbar-inverse" role="banner">
				<div class="container">
					<div class="header-top">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
					<div class="kiri"><h3><img src="icon/12924423_1710362155915688_6317663250708869046_n.jpg"class="img-square" id="img7"><b> Any Online Shop</b></h3></div>
					<div class="collapse navbar-collapse navbar-left">
						<ul class="nav navbar-nav">
							<a></a>
							<li><a href="index.php">Home</a></li> 
							<li><a href="#bottom">Produk</a></li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">Jasa  <i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu">
									<li><a href="#home3">Jasa Download</a></li>
									<li><a href="#home3">Jasa edting foto</a></li>
									<li><a href="#homee">Pembayaran Listrik</a></li>
									<li><a href="#homee">Pembayaran online</a></li>
									<li><a href="#homee">Jasa Pembelian tiket </a></li>
								</ul>
							</li> 
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">Voucher <i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu">
									<li><a href="#home2">Pulsa / Internet</a></li>
									<li><a href="#home2">Gemscool</a></li>
									<li><a href="#home2">Garena</a></li>
									<li><a href="#home2">Megaxus</a></li>
									<li><a href="#home2">Lyto</a></li>
									<li><a href="#home2">Zynga</a></li>
									<li><a href="#home2">Lyto</a></li>
								</ul>
							</li> 
							<li><a href="pesan.php">Contact</a></li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">Testimonial <i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu">
									<li><a href="">Jasa Download</a></li>
									<li><a href="">Voucher Games</a></li>
									<li><a href="">Pembayaran online</a></li>
									<li><a href="">Jasa editing gambar/foto</a></li>
									
								</ul>
							</li> 
                                      
						</ul>
					</div>
				</div><!--/.container-->
			</nav><!--/nav-->
		</section><!--/header-->
